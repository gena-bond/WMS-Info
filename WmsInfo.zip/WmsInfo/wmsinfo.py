# -*- coding: utf-8 -*-
#******************************************************************************
#
# WMSInfo
# ---------------------------------------------------------
#This plugin takes coordinates of a mouse click and gets information about WMS layer 
# from http://map.land.gov.ua/kadastrova-karta.
#
# Author:   
# *****************************************************************************
# Copyright (c) 2016
#
# This source is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 2 of the License, or (at your option)
# any later version.
#
# This code is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
# details.
#
# A copy of the GNU General Public License is available on the World Wide Web
# at <http://www.gnu.org/licenses/>. You can also obtain it by writing
# to the Free Software Foundation, 51 Franklin Street, Suite 500 Boston,
# MA 02110-1335 USA.
#
#******************************************************************************

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *

import wmsinfotool
import aboutdialog,settingsdialog

import resources
from os import path
import sys
_fs_encoding = sys.getfilesystemencoding()
_current_path = unicode(path.abspath(path.dirname(__file__)), _fs_encoding)

class WmsInfo:

    def __init__(self, iface):
        """Initialize class"""
        # Save reference to the QGIS interface
        self.iface = iface
        self.qgsVersion = unicode(QGis.QGIS_VERSION_INT)
        
        # Create the dialog (after translation) and keep reference
        #self.dlg = WmsInfoDialog()

        # Declare instance attributes
        #self.actions = []
        #self.menu = self.tr(u'&WMS Info')
        # TODO: We are going to let the user set this up in a future iteration
        #self.toolbar = self.iface.addToolBar(u'WmsInfo')
        #self.toolbar.setObjectName(u'WmsInfo')

        # i18n support
        override_locale = QSettings().value('locale/overrideFlag', False, type=bool)
        if not override_locale:
            locale_full_name = QLocale.system().name()
        else:
            locale_full_name = QSettings().value('locale/userLocale', '', type=unicode)

        self.locale_path = '%s/i18n/osminfo_%s.qm' % (_current_path, locale_full_name[0:2])
        if QFileInfo(self.locale_path).exists():
            self.translator = QTranslator()
            self.translator.load(self.locale_path)
            QCoreApplication.installTranslator(self.translator)
            # noinspection PyMethodMayBeStatic

    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('WmsInfo', message)
    

    def initGui(self):
        """Initialize graphic user interface"""
        #check if the plugin is ran below 2.0
        if int(self.qgsVersion) < 20000:
            qgisVersion = self.qgsVersion[0] + "." + self.qgsVersion[2] + "." + self.qgsVersion[3]
            QMessageBox.warning(self.iface.mainWindow(),
                            'OSMInfo', self.tr('Error'),
                            'OSMInfo', self.tr('QGIS %s detected.\n') % (qgisVersion) +
                            'OSMInfo', self.tr('This version of OSMInfo requires at least QGIS version 2.0.\nPlugin will not be enabled.'))
            return None

        #create action that will be run by the plugin
        self.actionRun = QAction('Get WMS info for a point', self.iface.mainWindow())

        self.actionRun.setIcon(QIcon(':/plugins/osminfo/icons/osminfo.png'))
        self.actionRun.setWhatsThis('Select point')
        self.actionRun.setStatusTip('Select point to get WMS data for')

        self.actionAbout = QAction('About WMSinfo', self.iface.mainWindow())
        self.actionAbout.setIcon(QIcon(':/plugins/osminfo/icons/about.png'))
        self.actionAbout.setWhatsThis('About WMSInfo')
        
        self.actionSettings = QAction('Settings', self.iface.mainWindow())
        self.actionSettings.setWhatsThis('Set various parameters related to WMSInfo')

        # add plugin menu to Web
        self.wmsinfo_menu = u'WMSInfo'
        self.iface.addPluginToWebMenu(self.wmsinfo_menu,self.actionRun)
        self.iface.addPluginToWebMenu(self.wmsinfo_menu,self.actionAbout)
        self.iface.addPluginToWebMenu(self.wmsinfo_menu,self.actionSettings)
    
        # add icon to new menu item in Web toolbar
        self.iface.addWebToolBarIcon(self.actionRun)

        # connect action to the run method
        self.actionRun.triggered.connect(self.run)
        self.actionAbout.triggered.connect(self.about)
        self.actionSettings.triggered.connect(self.settings)

        # prepare map tool
        self.mapTool = wmsinfotool.WMSInfotool(self.iface)
        #self.iface.mapCanvas().mapToolSet.connect(self.mapToolChanged

    def unload(self):
        """Actions to run when the plugin is unloaded"""
        # remove menu and icon from the menu
        self.iface.removeWebToolBarIcon(self.actionRun)
        self.iface.removePluginWebMenu('WMSInfo',self.actionAbout)
        self.iface.removePluginWebMenu('WMSInfo',self.actionSettings)
        self.iface.removePluginWebMenu('WMSInfo',self.actionRun)

        if self.iface.mapCanvas().mapTool() == self.mapTool:
            self.iface.mapCanvas().unsetMapTool(self.mapTool)

        del self.mapTool

    def run(self):
        """Action to run"""
        self.iface.mapCanvas().setMapTool(self.mapTool)

    def about(self):
        d = aboutdialog.AboutDialog()
        d.exec_()

    def settings(self):
        d = settingsdialog.SettingsDialog()
        d.exec_()
              
