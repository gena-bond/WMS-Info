# -*- coding: utf-8 -*-
#******************************************************************************
#
# WMSInfo
# ---------------------------------------------------------
# This plugin takes coordinates of a mouse click and gets information about all 
# objects from this point from WMS DZK.
#
# Author:   gena.bond, gena.bondarenko@i.ua
# *****************************************************************************
# Copyright (c) 2016 
#
# This source is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 2 of the License, or (at your option)
# any later version.
#
# This code is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
# details.
#
# A copy of the GNU General Public License is available on the World Wide Web
# at <http://www.gnu.org/licenses/>. You can also obtain it by writing
# to the Free Software Foundation, 51 Franklin Street, Suite 500 Boston,
# MA 02110-1335 USA.
#
#******************************************************************************
import json

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtNetwork import QNetworkRequest
from qgis.core import *

from wmsinfo_worker import Worker
import ast,re

FeatureItemType = 1001
TagItemType = 1002

class ResultsDialog(QDockWidget):
    def __init__(self, title, result_render, parent=None):
        self.__rb = result_render
        #self.__selected_id = None
        self.__rel_reply = None
        self.worker = None
        QDockWidget.__init__(self, title, parent)
        self.__mainWidget = QWidget()

        self.__layout = QVBoxLayout(self.__mainWidget)

        self.__resultsList = QListWidget(self)
        self.__resultsList.setMinimumSize(450, 20)
        self.__layout.addWidget(self.__resultsList)
        self.__resultsList.clear()

        self.setWidget(self.__mainWidget)

        overrideLocale = QSettings().value('locale/overrideFlag', False, type=bool)
        if not overrideLocale:
            self.qgisLocale = QLocale.system().name()[:2]
        else:
            self.qgisLocale = QSettings().value('locale/userLocale', '', type=unicode)[:2]


    def getInfo(self, xx, yy):
        self.__resultsList.clear()
        self.__resultsList.addItem(u'Завантаження....')
        if self.worker:
            self.worker.gotData.disconnect(self.showData)
            self.worker.gotError.disconnect(self.showError)
            self.worker.quit()
            self.worker.deleteLater()

        worker = Worker(xx, yy)
        worker.gotData.connect(self.showData)
        worker.gotError.connect(self.showError)
        worker.start()

        self.worker = worker

    def showError(self, msg):
        self.__resultsList.clear()
        self.__resultsList.addItem(QListWidgetItem([msg]))

    def showData(self, l1):
        self.__resultsList.clear()
        self.__resultsList.addItem(u"Інформація про земельну ділянку:")
        result_dict=ast.literal_eval(str(l1[0]))
        #Разбор семантики
        if result_dict.get('dilanka')<>None:
            str_dil=result_dict['dilanka']
            str_ikk=result_dict['ikk']
            str_rajon=result_dict['rajonunion']
            str_obl=result_dict['obl']
  
            reg_exp=re.compile(ur":<./div>(.*?)<",re.U|re.I)
            kad_num = re.compile(ur"[0-9]{10}:[0-9]{2}:[0-9]{3}:[0-9]{4}",re.U)
  
            s_all_dilanka=reg_exp.findall(str_dil)
            #print s_all_dilanka
            s_kad_num=kad_num.findall(str_dil)[0]
            #print "kad: ",s_kad_num
            vlastn=s_all_dilanka[1]
            goal=s_all_dilanka[2]
            area=s_all_dilanka[3]
            
            s_all_ikk=reg_exp.findall(str_ikk)
            district=s_all_ikk[0]
            koatuu=s_all_ikk[1]
            zone=s_all_ikk[2]
            kvartal=s_all_ikk[3]
            
            self.__resultsList.addItem(u"Кадастровий номер: "+s_kad_num.decode('unicode-escape'))
            self.__resultsList.addItem(u"Тип власностi: "+vlastn.decode('unicode-escape'))
            self.__resultsList.addItem(u"Цiльове призначення: "+goal.decode('unicode-escape'))
            self.__resultsList.addItem(u"Площа: "+area.decode('unicode-escape'))
            self.__resultsList.addItem(u"Район: "+district.decode('unicode-escape'))
            self.__resultsList.addItem(u"КОАТУУ: "+koatuu.decode('unicode-escape'))
            self.__resultsList.addItem(u"Зона: "+zone.decode('unicode-escape'))
            self.__resultsList.addItem(u"Квартал: "+kvartal.decode('unicode-escape'))            
        else:
            self.__resultsList.clear()
            self.__resultsList.addItem(u"У запит не потрапило жодної земельної дiлянки !")
            

        

    # def selItemChanged(self):
    #     selection = self.__resultsTree.selectedItems()
    #     if not selection:
    #         return
    #     item = selection[0]
    #     # if selected tag - use parent
    #     if item.type() == TagItemType:
    #         item = item.parent()
    #     # if already selected - exit
    #     if self.__selected_id == item:
    #         return
    #     # clear old highlights
    #     self.__rb.clear_feature()
    #     # set new
    #     if item and item.type() == FeatureItemType:
    #         self.__selected_id = item
    #         element = item.data(0, Qt.UserRole)
    #         if element:
    #             if element['type'] == 'node':
    #                 geom = QgsGeometry.fromPoint(QgsPoint(element['lon'], element['lat']))
    #             if element['type'] == 'way':
    #                 geom = QgsGeometry.fromPolyline([QgsPoint(g['lon'], g['lat']) for g in element['geometry'] if g!='null'])
    #             if element['type'] == 'relation':
    #                 self.sendRelationRequest(element['id'])
    #                 return
    #             self.__rb.show_feature(geom)

    # def sendRelationRequest(self, relation_id):
    #     if self.__rel_reply:
    #         try:
    #             self.__rel_reply.abort()
    #             self.__rel_reply.finished.disconnect(self.showRelationGeom)
    #         except:
    #             pass
    #     url = 'http://overpass-api.de/api/interpreter'
    #     rel_request = QNetworkRequest(QUrl(url))
    #     qnam = QgsNetworkAccessManager.instance()
    #     request_data = '[out:json];rel(%s);out geom;' % (relation_id)
    #     self.__rel_reply = qnam.post(rel_request, QByteArray(request_data))
    #     self.__rel_reply.finished.connect(self.showRelationGeom)
    #     self.__rel_reply.error.connect(lambda: 'ok')

    # def showRelationGeom(self):
    #     rel_data = ()
    #     try:
    #         data = self.__rel_reply.readAll()
    #         self.__rel_reply.finished.disconnect(self.showRelationGeom)
    #         rel_data = json.loads(str(data))
    #     except:
    #         pass
    #     if 'elements' in rel_data and len(rel_data['elements']) > 0:
    #         element = rel_data['elements'][0]
    #         if 'members' in element:
    #             lines = []
    #             for member in element['members']:
    #                 if member['type'] == 'way' and member['role'] == 'outer':
    #                     lines.append([QgsPoint(g['lon'], g['lat']) for g in member['geometry'] if g != 'null'])
    #             geom =QgsGeometry.fromMultiPolyline(lines)
    #             self.__rb.show_feature(geom)