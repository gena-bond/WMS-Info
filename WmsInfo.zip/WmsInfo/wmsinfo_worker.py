# -*- coding: utf-8 -*-
#******************************************************************************
#
# OSMInfo
# ---------------------------------------------------------
# This plugin takes coordinates of a mouse click and gets information about all 
# objects from this point from OSM using Overpass API.
#
# Author:   Maxim Dubinin, sim@gis-lab.info
# Author:   Alexander Lisovenko, alexander.lisovenko@nextgis.ru
# *****************************************************************************
# Copyright (c) 2012-2015. NextGIS, info@nextgis.com

# This source is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 2 of the License, or (at your option)
# any later version.
#
# This code is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
# details.
#
# A copy of the GNU General Public License is available on the World Wide Web
# at <http://www.gnu.org/licenses/>. You can also obtain it by writing
# to the Free Software Foundation, 51 Franklin Street, Suite 500 Boston,
# MA 02110-1335 USA.
#
#******************************************************************************

import json,ast

from PyQt4.QtCore import pyqtSignal, QUrl, QByteArray, QEventLoop, QThread
from PyQt4.QtNetwork import QNetworkRequest, QNetworkReply
from qgis.core import QgsMessageLog, QgsNetworkAccessManager
from urllib import urlencode

from plugin_settings import PluginSettings
#import httplib 
from urllib import urlencode

class Worker(QThread):

    gotData = pyqtSignal(list)
    gotError = pyqtSignal(unicode)

    def __init__(self, xx, yy):
        super(Worker, self).__init__()
        self.__xx = xx
        self.__yy = yy
        #print xx, yy

    def run(self):
       
        yy = str(self.__xx)
        xx = str(self.__yy)
        url = 'http://map.land.gov.ua//kadastrova-karta/getobjectinfo'
        request = QNetworkRequest(QUrl(url))
        

        headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36",
        "Accept": "application/json , text/javascript, */*; q=0.01",
        "Accept-Encoding":"gzip, deflate",  
        "Accept-Language": "en-US,en;q=0.8,ru;q=0.6",
        "Connection": "keep-alive",
        "X-Requested-With":"XMLHttpRequest",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Referer": "http://map.land.gov.ua/kadastrova-karta/getobjectinfo"}
        request.setHeader(QNetworkRequest.ContentTypeHeader, headers);
        
        #con.request("POST","/kadastrova-karta/getobjectinfo",str_reqest,headers=headers)
        #result_data=con.getresponse().read()
        #Преобразование результата ответа сервера в словарь
        #result_dict=ast.literal_eval(result_data)

        qnam = QgsNetworkAccessManager.instance()

        # around request
        #dist = PluginSettings.distance_value()
        #timeout = PluginSettings.timeout_value()

        #request_data = '[timeout:%s][out:json];(node(around:%s,%s,%s);way(around:%s,%s,%s));out tags geom;relation(around:%s,%s,%s);' % (timeout, dist, yy, xx, dist, yy, xx, dist, yy, xx)
        #print xx,yy
        request_data=urlencode({'x':xx,'y':yy,'zoom':'14'})+"&actLayers%5B%5D=kadastr"

        reply1 = qnam.post(request,QByteArray(request_data))
        loop = QEventLoop()
        reply1.finished.connect(loop.quit)
        loop.exec_()

        data = reply1.readAll()
        #print type(data)
        #l1=ast.literal_eval(data)
        #l = json.loads(str(data))
        #l1=json.dumps(l)
        arr=[]
        arr.append(data)
        self.gotData.emit(arr)
