# -*- coding: utf-8 -*-
#******************************************************************************
#
# WMSInfo
# ---------------------------------------------------------
# This plugin takes coordinates of a mouse click and gets information about WMS layer 
# from http://map.land.gov.ua/kadastrova-karta.
#
# Author: Gennady Bondarenko 
# *****************************************************************************
# Copyright (c) 2016 
#
# This source is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 2 of the License, or (at your option)
# any later version.
#
# This code is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
# details.
#
# A copy of the GNU General Public License is available on the World Wide Web
# at <http://www.gnu.org/licenses/>. You can also obtain it by writing
# to the Free Software Foundation, 51 Franklin Street, Suite 500 Boston,
# MA 02110-1335 USA.
#
#******************************************************************************
import json

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtNetwork import QNetworkRequest
from qgis.core import *

from wmsinfo_worker import Worker
import ast,re

FeatureItemType = 1001
TagItemType = 1002

class ResultsDialog(QDockWidget):
    def __init__(self, title, result_render, parent=None):
        self.__rb = result_render
        #self.__selected_id = None
        self.__rel_reply = None
        self.worker = None
        QDockWidget.__init__(self, title, parent)
        self.__mainWidget = QWidget()

        self.__layout = QVBoxLayout(self.__mainWidget)

        self.__resultsList = QTextBrowser(self)
        self.__resultsList.setMinimumSize(450, 20)
        self.__layout.addWidget(self.__resultsList)
        self.__resultsList.clear()

        self.setWidget(self.__mainWidget)

        overrideLocale = QSettings().value('locale/overrideFlag', False, type=bool)
        if not overrideLocale:
            self.qgisLocale = QLocale.system().name()[:2]
        else:
            self.qgisLocale = QSettings().value('locale/userLocale', '', type=unicode)[:2]


    def getInfo(self, xx, yy):
        self.__resultsList.clear()
        self.__resultsList.append(u'Завантаження....')
        if self.worker:
            self.worker.gotData.disconnect(self.showData)
            self.worker.gotError.disconnect(self.showError)
            self.worker.quit()
            self.worker.deleteLater()

        worker = Worker(xx, yy)
        worker.gotData.connect(self.showData)
        worker.gotError.connect(self.showError)
        worker.start()

        self.worker = worker

    def showError(self, msg):
        self.__resultsList.clear()
        self.__resultsList.addItem(QListWidgetItem([msg]))

    def showData(self, l1):
        self.__resultsList.clear()
        result_dict=ast.literal_eval(str(l1[0]))
        #Разбор семантики
        if result_dict.get('dilanka')<>None:
            str_dil=result_dict['dilanka']
            str_ikk=result_dict['ikk']
            str_rajon=result_dict['rajonunion']
            str_obl=result_dict['obl']
            reg_exp=re.compile(ur":<./div>(.*?)<",re.U|re.I)
            kad_num = re.compile(ur"[0-9]{10}:[0-9]{2}:[0-9]{3}:[0-9]{4}",re.U)
          
            s_all_dilanka=reg_exp.findall(str_dil)
            s_all_ikk=reg_exp.findall(str_ikk)
            s_kad_num=kad_num.findall(str_dil)

            
            if len(s_kad_num)<=4:
                s_kad_num=kad_num.findall(str_dil)[0]
                
                if len(s_all_dilanka)==4: #Если один участок
                    vlastn=s_all_dilanka[1]
                    goal=s_all_dilanka[2]
                    area=s_all_dilanka[3]
                    self.__resultsList.append(u"Інформація про земельну ділянку:")
                    self.__resultsList.append(u"Кадастровий номер: "+s_kad_num.decode('unicode-escape'))
                    self.__resultsList.append(u"Тип власностi: "+vlastn.decode('unicode-escape'))
                    self.__resultsList.append(u"Цiльове призначення: "+goal.decode('unicode-escape'))
                    self.__resultsList.append(u"Площа: "+area.decode('unicode-escape'))                
                elif len(s_all_dilanka)==3: #Нет 
                    vlastn=s_all_dilanka[1]
                    goal=u"Не визначено"
                    area=s_all_dilanka[2]
                    self.__resultsList.append(u"Інформація про земельну ділянку:")
                    self.__resultsList.append(u"Кадастровий номер: "+s_kad_num.decode('unicode-escape'))
                    self.__resultsList.append(u"Тип власностi: "+vlastn.decode('unicode-escape'))
                    self.__resultsList.append(u"Цiльове призначення: "+goal)
                    self.__resultsList.append(u"Площа: "+area.decode('unicode-escape'))
                
                
                district=s_all_ikk[0]
                koatuu=s_all_ikk[1]
                zone=s_all_ikk[2]
                kvartal=s_all_ikk[3]
                self.__resultsList.append(u"Район: "+district.decode('unicode-escape'))
                self.__resultsList.append(u"КОАТУУ: "+koatuu.decode('unicode-escape'))
                self.__resultsList.append(u"Зона: "+zone.decode('unicode-escape'))
                self.__resultsList.append(u"Квартал: "+kvartal.decode('unicode-escape'))            
            else:
                s_kad_num=set(s_kad_num) #оставляем только уникальные значения
                s_kad_num_local=list(s_kad_num)
                if len(s_kad_num)==1: #Если на публичной карте два участка с одинаковым кадастровым номером
                    
                    s_kad_num_local.append(s_kad_num_local[0])
                    for y in range(1,len(s_kad_num_local)+1):  
                        vlastn=s_all_dilanka[y+3*(y-1)]
                        goal=s_all_dilanka[y+3*(y-1)+1]
                        area=s_all_dilanka[y+3*(y-1)+2]                    
                        district=s_all_ikk[0]                    
                        koatuu=s_all_ikk[1]                    
                        zone=s_all_ikk[2]                    
                        kvartal=s_all_ikk[3]
                        self.__resultsList.append(u"Інформація про земельну ділянку:")
                        self.__resultsList.append(u"Кадастровий номер: "+s_kad_num_local[y-1].decode('unicode-escape'))
                        self.__resultsList.append(u"Тип власностi: "+vlastn.decode('unicode-escape'))
                        self.__resultsList.append(u"Цiльове призначення: "+goal.decode('unicode-escape'))
                        self.__resultsList.append(u"Площа: "+area.decode('unicode-escape'))
                                    
                        self.__resultsList.append(u"Район: "+district.decode('unicode-escape'))
                        self.__resultsList.append(u"КОАТУУ: "+koatuu.decode('unicode-escape'))
                        self.__resultsList.append(u"Зона: "+zone.decode('unicode-escape'))
                        self.__resultsList.append(u"Квартал: "+kvartal.decode('unicode-escape'))  
                        self.__resultsList.append("")
                else:    
                    
                    for y in range(1,len(s_kad_num)+1):  
                        vlastn=s_all_dilanka[y+3*(y-1)]
                        goal=s_all_dilanka[y+3*(y-1)+1]
                        area=s_all_dilanka[y+3*(y-1)+2]                    
                        district=s_all_ikk[0]                    
                        koatuu=s_all_ikk[1]                    
                        zone=s_all_ikk[2]                    
                        kvartal=s_all_ikk[3]
                        self.__resultsList.append(u"Інформація про земельну ділянку:")
                        self.__resultsList.append(u"Кадастровий номер: "+s_kad_num_local[y-1].decode('unicode-escape'))
                        self.__resultsList.append(u"Тип власностi: "+vlastn.decode('unicode-escape'))
                        self.__resultsList.append(u"Цiльове призначення: "+goal.decode('unicode-escape'))
                        self.__resultsList.append(u"Площа: "+area.decode('unicode-escape'))
                                    
                        self.__resultsList.append(u"Район: "+district.decode('unicode-escape'))
                        self.__resultsList.append(u"КОАТУУ: "+koatuu.decode('unicode-escape'))
                        self.__resultsList.append(u"Зона: "+zone.decode('unicode-escape'))
                        self.__resultsList.append(u"Квартал: "+kvartal.decode('unicode-escape'))  
                        self.__resultsList.append("")
              
        else:
            self.__resultsList.clear()
            self.__resultsList.append(u"У запит не потрапило жодної земельної дiлянки !")
            